"""Passes for Jac."""

from jaclang.jac0core.passes.ast_gen import BaseAstGenPass
from jaclang.jac0core.passes.uni_pass import Transform, UniPass

__all__ = ["Transform", "UniPass", "BaseAstGenPass"]
